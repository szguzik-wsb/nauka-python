# Definiujemy stałą stawkę VAT
VAT_RATE = 0.23
